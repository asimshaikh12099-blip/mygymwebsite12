/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Programs } from './components/Programs';
import { AboutFacility } from './components/AboutFacility';
import { Schedule } from './components/Schedule';
import { Pricing } from './components/Pricing';
import { BmiCalculator } from './components/BmiCalculator';
import { Trainers } from './components/Trainers';
import { Gallery } from './components/Gallery';
import { Testimonials } from './components/Testimonials';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { WhatsAppFloating } from './components/WhatsAppFloating';
import { BookingPassModal } from './components/BookingPassModal';

export default function App() {
  const [isPassModalOpen, setIsPassModalOpen] = useState(false);
  const [modalProgramInterest, setModalProgramInterest] = useState('All-Access 3-Day Pass');

  const handleOpenPassModal = (programName?: string) => {
    if (programName) {
      setModalProgramInterest(programName);
    } else {
      setModalProgramInterest('All-Access 3-Day Pass');
    }
    setIsPassModalOpen(true);
  };

  const handleSelectProgram = (programTitle: string) => {
    handleOpenPassModal(`Program: ${programTitle}`);
  };

  const handleSelectPlan = (planName: string) => {
    handleOpenPassModal(`Membership Tier: ${planName}`);
  };

  const handleBookTrainer = (trainerName: string) => {
    handleOpenPassModal(`1-on-1 Consult with ${trainerName}`);
  };

  const handleRecommendProgram = (programName: string) => {
    handleOpenPassModal(`Recommended: ${programName}`);
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-black">
      {/* Navigation Bar */}
      <Navbar onOpenPassModal={() => handleOpenPassModal()} />

      {/* Main Sections */}
      <main className="flex-1">
        <Hero onOpenPassModal={() => handleOpenPassModal()} />
        <Programs onSelectProgramForPass={handleSelectProgram} />
        <AboutFacility onOpenPassModal={() => handleOpenPassModal()} />
        <Schedule onOpenPassModal={() => handleOpenPassModal()} />
        <Pricing onSelectPlan={handleSelectPlan} />
        <BmiCalculator onRecommendProgram={handleRecommendProgram} />
        <Trainers onBookTrainer={handleBookTrainer} />
        <Gallery />
        <Testimonials />
        <FaqSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer onOpenPassModal={() => handleOpenPassModal()} />

      {/* Floating WhatsApp Action Widget */}
      <WhatsAppFloating />

      {/* 3-Day Free Pass Booking & Generation Modal */}
      <BookingPassModal
        isOpen={isPassModalOpen}
        onClose={() => setIsPassModalOpen(false)}
        defaultProgram={modalProgramInterest}
      />
    </div>
  );
}
