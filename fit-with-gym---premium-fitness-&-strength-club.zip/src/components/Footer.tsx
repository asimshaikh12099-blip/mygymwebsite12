import React from 'react';
import { Dumbbell, Phone, Mail, MapPin, Clock, MessageSquare, Instagram, Facebook, Youtube, ArrowUp } from 'lucide-react';
import { BUSINESS_INFO } from '../data/gymData';
import { ZipExporter } from './ZipExporter';

interface FooterProps {
  onOpenPassModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPassModal }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Hi Fit With Gym! I would like to get in touch.'
  )}`;

  return (
    <footer className="bg-[#070a10] border-t border-white/10 pt-16 pb-12 text-slate-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Export Banner */}
        <div className="mb-14">
          <ZipExporter />
        </div>

        {/* Main Footer Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <a href="#" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-bold">
                <Dumbbell className="w-5 h-5" />
              </div>
              <span className="font-display text-3xl font-bold tracking-wider text-white">
                FIT WITH GYM
              </span>
            </a>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              Metropolis's destination for elite strength conditioning, metabolic interval training, and contrast thermal recovery. Engineered for everyday lifters and competitive athletes.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-[#25D366] hover:text-black flex items-center justify-center transition-colors text-slate-300"
                aria-label="WhatsApp"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-amber-400 hover:text-black flex items-center justify-center transition-colors text-slate-300"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-amber-400 hover:text-black flex items-center justify-center transition-colors text-slate-300"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-amber-400 hover:text-black flex items-center justify-center transition-colors text-slate-300"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg font-bold text-white uppercase tracking-wider mb-4">
              Explore
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#programs" className="hover:text-amber-400 transition-colors">
                  Training Programs
                </a>
              </li>
              <li>
                <a href="#facility" className="hover:text-amber-400 transition-colors">
                  Facility & Amenities
                </a>
              </li>
              <li>
                <a href="#schedule" className="hover:text-amber-400 transition-colors">
                  Class Timetable
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-amber-400 transition-colors">
                  Memberships & Pricing
                </a>
              </li>
              <li>
                <a href="#calculator" className="hover:text-amber-400 transition-colors">
                  BMI & Caloric Tool
                </a>
              </li>
              <li>
                <a href="#coaches" className="hover:text-amber-400 transition-colors">
                  Master Coaches
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-amber-400 transition-colors">
                  Photo Gallery
                </a>
              </li>
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="font-display text-lg font-bold text-white uppercase tracking-wider mb-4">
              Disciplines
            </h4>
            <ul className="space-y-2 text-xs">
              <li className="text-slate-300">Hypertrophy & Strength Lab</li>
              <li className="text-slate-300">Metabolic Ignite HIIT</li>
              <li className="text-slate-300">Functional Athletic Grit</li>
              <li className="text-slate-300">Vinyasa & Thermal Mobility</li>
              <li className="text-slate-300">1-on-1 Bespoke Coaching</li>
              <li className="text-slate-300">Finnish Sauna & Cold Plunge</li>
            </ul>
          </div>

          {/* Hours & Contact */}
          <div>
            <h4 className="font-display text-lg font-bold text-white uppercase tracking-wider mb-4">
              Visit Us
            </h4>
            <div className="space-y-2.5 text-xs">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{BUSINESS_INFO.address}, {BUSINESS_INFO.city}</span>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Mon-Fri: {BUSINESS_INFO.hours.weekdays}</span>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Sat-Sun: {BUSINESS_INFO.hours.weekends}</span>
              </p>
              <p className="flex items-center gap-2 text-amber-400 font-semibold">
                <Phone className="w-4 h-4 shrink-0" />
                <span>{BUSINESS_INFO.phone}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} {BUSINESS_INFO.name}. All rights reserved. Built for static deployment on Cloudflare Pages.
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={onOpenPassModal}
              className="text-amber-400 hover:underline font-semibold cursor-pointer"
            >
              Get Free 3-Day Pass
            </button>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
