import React, { useState } from 'react';
import { FAQS, BUSINESS_INFO } from '../data/gymData';
import { HelpCircle, ChevronDown, MessageSquare } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-20 lg:py-28 bg-[#0e1422] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            Frequently Answered Questions
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            EVERYTHING YOU <span className="text-gradient-gold">NEED TO KNOW</span>
          </h2>
          <p className="mt-4 text-base text-slate-300">
            Got questions about joining, our 3-day free pass, or facilities? Here are straightforward answers.
          </p>
        </div>

        {/* Accordion list */}
        <div className="mt-12 space-y-3.5">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="glass-card rounded-2xl border border-white/10 overflow-hidden transition-all"
              >
                <button
                  onClick={() => toggle(index)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                >
                  <span className="font-display text-xl sm:text-2xl font-bold text-white tracking-wide">
                    {faq.q}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-amber-400 shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 bg-amber-400 text-black' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 pt-0 text-sm sm:text-base text-slate-300 leading-relaxed border-t border-white/5 mt-1">
                    <p className="pt-3">{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions banner */}
        <div className="mt-10 p-6 rounded-2xl bg-white/5 border border-white/10 text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="text-sm font-bold text-white">Have a specific question not covered here?</h4>
            <p className="text-xs text-slate-400 mt-0.5">Our front desk concierge is online 7 days a week on WhatsApp.</p>
          </div>
          <a
            href={`https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
              "Hi Fit With Gym! I have a question about the gym."
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-xl bg-[#25D366] text-black font-bold text-xs flex items-center gap-2 hover:bg-[#20ba59] transition-all whitespace-nowrap"
          >
            <MessageSquare className="w-4 h-4" />
            Chat With Concierge
          </a>
        </div>
      </div>
    </section>
  );
};
