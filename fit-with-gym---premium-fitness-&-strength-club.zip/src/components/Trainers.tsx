import React, { useState } from 'react';
import { TRAINERS, BUSINESS_INFO } from '../data/gymData';
import { Trainer } from '../types';
import { Award, Dumbbell, Quote, MessageSquare, CheckCircle, Sparkles } from 'lucide-react';

interface TrainersProps {
  onBookTrainer: (trainerName: string) => void;
}

export const Trainers: React.FC<TrainersProps> = ({ onBookTrainer }) => {
  return (
    <section id="coaches" className="py-20 lg:py-28 bg-[#0e1422] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Award className="w-3.5 h-3.5" />
            Certified Master Coaches
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            MEET THE <span className="text-gradient-gold">PERFORMANCE TEAM</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            No cookie-cutter fitness influencers. Our coaches hold graduate degrees in exercise science, national strength certifications, and decades of podium results.
          </p>
        </div>

        {/* Coaches Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TRAINERS.map((trainer) => (
            <div
              key={trainer.id}
              className="glass-card rounded-2xl overflow-hidden flex flex-col justify-between border border-white/10 hover:border-amber-400/40 group"
            >
              <div>
                {/* Image */}
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={trainer.image}
                    alt={trainer.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-95"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#121927] via-transparent to-transparent" />
                  <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-bold text-amber-400 border border-amber-400/30">
                    {trainer.experience}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-display text-2xl font-bold text-white group-hover:text-amber-400 transition-colors">
                    {trainer.name}
                  </h3>
                  <div className="text-xs font-semibold text-amber-400 mb-3">
                    {trainer.role}
                  </div>

                  <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed mb-4">
                    {trainer.bio}
                  </p>

                  {/* Certifications */}
                  <div className="space-y-1 pt-3 border-t border-white/10">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Credentials:</div>
                    <div className="flex flex-wrap gap-1">
                      {trainer.certifications.map((c, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/5">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Specialties */}
                  <div className="space-y-1 mt-3">
                    <div className="text-[10px] uppercase font-bold text-slate-400">Specialties:</div>
                    <div className="flex flex-wrap gap-1">
                      {trainer.specialties.map((s, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-amber-400/10 text-amber-300">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Quote & Action */}
              <div className="p-5 pt-0">
                <blockquote className="text-[11px] italic text-slate-400 p-2.5 rounded-lg bg-white/5 border-l-2 border-amber-400 mb-4">
                  "{trainer.quote}"
                </blockquote>

                <button
                  onClick={() => onBookTrainer(trainer.name)}
                  className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-amber-400 hover:text-black text-white font-bold text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Book 1-on-1 Consult</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
