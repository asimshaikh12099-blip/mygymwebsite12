import React, { useState } from 'react';
import { X, Sparkles, CheckCircle, QrCode, Printer, Send, ShieldCheck, Dumbbell, Calendar, Clock, Download } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BUSINESS_INFO } from '../data/gymData';
import { PassBooking } from '../types';

interface BookingPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultProgram?: string;
}

export const BookingPassModal: React.FC<BookingPassModalProps> = ({
  isOpen,
  onClose,
  defaultProgram = 'All-Access Strength & Conditioning',
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    goal: 'Build Muscle & Strength',
    programInterest: defaultProgram,
  });

  const [generatedPass, setGeneratedPass] = useState<PassBooking | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    confetti({
      particleCount: 85,
      spread: 75,
      origin: { y: 0.6 }
    });

    const passCode = `FWG-${Math.floor(100000 + Math.random() * 900000)}`;
    setGeneratedPass({
      fullName: formData.name,
      email: formData.email,
      phone: formData.phone,
      preferredDate: formData.preferredDate,
      goal: formData.goal,
      programInterest: formData.programInterest || defaultProgram,
      passCode,
      generatedAt: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    setGeneratedPass(null);
    onClose();
  };

  const whatsappPassUrl = generatedPass
    ? `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
        `Hi Fit With Gym! I just generated my 3-Day Free VIP Pass (Pass #${generatedPass.passCode}) for ${generatedPass.fullName}. I'd like to visit starting ${generatedPass.preferredDate} for ${generatedPass.programInterest}.`
      )}`
    : '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/85 backdrop-blur-md"
        onClick={handleReset}
      />

      <div className="relative w-full max-w-lg bg-[#111726] border border-white/20 rounded-3xl p-6 sm:p-8 shadow-2xl z-10 max-h-[92vh] overflow-y-auto">
        <button
          onClick={handleReset}
          className="absolute top-5 right-5 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!generatedPass ? (
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              Zero Commitment • 100% Free
            </div>

            <h3 className="font-display text-3xl sm:text-4xl font-bold text-white uppercase leading-tight">
              CLAIM YOUR <span className="text-gradient-gold">3-DAY FREE PASS</span>
            </h3>

            <p className="mt-2 text-xs sm:text-sm text-slate-300">
              Experience all 16,500 sq ft, Olympic barbell bays, group classes, and recovery cedar sauna for 3 consecutive days.
            </p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Marcus Miller"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Phone (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 000-0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="marcus@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Preferred Visit Date
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.preferredDate}
                    onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Main Transformation Goal
                  </label>
                  <select
                    value={formData.goal}
                    onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-[#141b2a] border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
                  >
                    <option>Build Muscle & Strength</option>
                    <option>Fat Loss & Metabolic HIIT</option>
                    <option>Athletic Conditioning & Agility</option>
                    <option>Joint Mobility & Injury Rehab</option>
                    <option>General Longevity & Wellness</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Program or Area of Interest
                </label>
                <input
                  type="text"
                  value={formData.programInterest}
                  onChange={(e) => setFormData({ ...formData, programInterest: e.target.value })}
                  placeholder="e.g. Hypertrophy, HIIT, Sauna"
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-sm uppercase tracking-wider shadow-xl shadow-amber-400/25 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  Generate My VIP Pass
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 pt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>No credit card required. Show pass on phone at check-in.</span>
              </div>
            </form>
          </div>
        ) : (
          <div>
            {/* VIP Pass Card Display */}
            <div className="text-center mb-4">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold mb-1">
                <CheckCircle className="w-3.5 h-3.5" />
                Pass Activated Successfully
              </div>
              <h3 className="font-display text-2xl font-bold text-white uppercase">
                Your Official VIP Guest Pass
              </h3>
            </div>

            {/* Realistic Digital Membership Pass Ticket */}
            <div className="bg-gradient-to-br from-[#1b253a] via-[#161e30] to-[#0f1523] border-2 border-amber-400/50 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
              {/* Gold watermark */}
              <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between pb-4 border-b border-white/15">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-400 text-black flex items-center justify-center font-bold">
                    <Dumbbell className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-display text-xl font-bold text-white tracking-wider">
                      FIT WITH GYM
                    </div>
                    <div className="text-[9px] uppercase tracking-widest text-amber-400">
                      3-Day All-Access Pass
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">PASS CODE</span>
                  <span className="font-mono text-sm font-bold text-amber-400">
                    {generatedPass.passCode}
                  </span>
                </div>
              </div>

              <div className="py-4 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Guest Name:</span>
                  <span className="font-bold text-white">{generatedPass.fullName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Starting Date:</span>
                  <span className="font-bold text-white">{generatedPass.preferredDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Program Focus:</span>
                  <span className="font-bold text-amber-300">{generatedPass.programInterest}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Access Tier:</span>
                  <span className="font-bold text-emerald-400">All Zones + Cedar Sauna + Classes</span>
                </div>
              </div>

              {/* Simulated QR & Barcode Section */}
              <div className="pt-4 border-t border-dashed border-white/15 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-white p-1 rounded-lg flex items-center justify-center">
                    <QrCode className="w-12 h-12 text-black" />
                  </div>
                  <div className="text-[10px] text-slate-400">
                    <div>Scan at turnstile or front desk</div>
                    <div className="text-slate-500">Valid for 3 consecutive visits</div>
                  </div>
                </div>

                <div className="text-right text-[10px] font-mono text-slate-500">
                  METROPOLIS CAMPUS
                </div>
              </div>
            </div>

            {/* Pass Actions */}
            <div className="mt-6 space-y-3">
              <a
                href={whatsappPassUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 rounded-xl bg-[#25D366] text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-[#20ba59] transition-all shadow-lg shadow-[#25D366]/20"
              >
                <Send className="w-4 h-4 fill-black" />
                <span>Confirm & Send to WhatsApp</span>
              </a>

              <div className="flex gap-2">
                <button
                  onClick={handlePrint}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs flex items-center justify-center gap-2 border border-white/10"
                >
                  <Printer className="w-4 h-4 text-amber-400" />
                  <span>Print / Save Pass</span>
                </button>

                <button
                  onClick={handleReset}
                  className="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
