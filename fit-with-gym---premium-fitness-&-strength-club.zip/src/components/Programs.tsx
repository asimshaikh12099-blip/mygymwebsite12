import React, { useState } from 'react';
import { PROGRAMS } from '../data/gymData';
import { Program } from '../types';
import { Flame, Clock, Zap, CheckCircle2, Dumbbell, X, ArrowRight, Sparkles } from 'lucide-react';

interface ProgramsProps {
  onSelectProgramForPass: (programTitle: string) => void;
}

export const Programs: React.FC<ProgramsProps> = ({ onSelectProgramForPass }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeModalProgram, setActiveModalProgram] = useState<Program | null>(null);

  const categories = [
    { id: 'all', label: 'All Programs' },
    { id: 'strength', label: 'Strength & Hypertrophy' },
    { id: 'hiit', label: 'Metabolic HIIT' },
    { id: 'functional', label: 'Functional Athletic' },
    { id: 'mobility', label: 'Mobility & Recovery' },
    { id: 'personal', label: '1-on-1 Coaching' },
  ];

  const filteredPrograms =
    selectedCategory === 'all'
      ? PROGRAMS
      : PROGRAMS.filter((p) => p.category === selectedCategory);

  return (
    <section id="programs" className="py-20 lg:py-28 bg-[#0e1422] relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Dumbbell className="w-3.5 h-3.5" />
            Engineered For Transformation
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            WORLD-CLASS TRAINING <span className="text-gradient-gold">PROGRAMS</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            Whether your mission is adding dense lean muscle, stripping body fat, or moving without pain, our programs are grounded in exercise physiology and led by master coaches.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2 sm:gap-3">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/20 scale-105'
                  : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Programs Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPrograms.map((program) => (
            <div
              key={program.id}
              className="glass-card rounded-2xl overflow-hidden flex flex-col group border border-white/10 hover:border-amber-400/40"
            >
              {/* Image & overlay badges */}
              <div className="relative h-60 overflow-hidden">
                <img
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 filter brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0e1422] via-transparent to-black/30" />

                {/* Level badge */}
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-slate-200 border border-white/10">
                  {program.level}
                </div>

                {/* Intensity meter */}
                <div className="absolute top-4 right-4 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-amber-400 border border-amber-400/30">
                  <Flame className="w-3.5 h-3.5 fill-amber-400" />
                  {program.intensity}
                </div>

                {/* Duration & Calories pill */}
                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-slate-300 font-medium">
                  <span className="flex items-center gap-1.5 bg-[#0e1422]/90 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-white/10">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    {program.duration}
                  </span>
                  <span className="flex items-center gap-1.5 bg-[#0e1422]/90 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-white/10">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    {program.calories}
                  </span>
                </div>
              </div>

              {/* Content body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-display text-2xl font-bold text-white group-hover:text-amber-400 transition-colors">
                    {program.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-300 line-clamp-2">
                    {program.shortDesc}
                  </p>

                  {/* Program key highlights */}
                  <div className="mt-4 space-y-1.5">
                    {program.benefits.slice(0, 2).map((b, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card footer CTA buttons */}
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setActiveModalProgram(program)}
                    className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>View Curriculum</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onSelectProgramForPass(program.title)}
                    className="px-3.5 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold transition-all shadow-md shadow-amber-400/20 cursor-pointer"
                  >
                    Try Free Session
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Program Deep-Dive Modal */}
      {activeModalProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => setActiveModalProgram(null)}
          />

          <div className="relative w-full max-w-2xl bg-[#121927] border border-white/15 rounded-2xl p-6 sm:p-8 shadow-2xl z-10 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setActiveModalProgram(null)}
              className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4" />
              Program Breakdown
            </div>

            <h3 className="font-display text-3xl sm:text-4xl font-bold text-white uppercase">
              {activeModalProgram.title}
            </h3>

            <div className="mt-4 flex flex-wrap gap-2 text-xs">
              <span className="px-3 py-1 rounded-full bg-white/10 text-slate-200">
                Level: {activeModalProgram.level}
              </span>
              <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                Duration: {activeModalProgram.duration}
              </span>
              <span className="px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                Intensity: {activeModalProgram.intensity}
              </span>
              <span className="px-3 py-1 rounded-full bg-purple-400/20 text-purple-300 border border-purple-400/30">
                Est. Burn: {activeModalProgram.calories}
              </span>
            </div>

            <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
              {activeModalProgram.fullDesc}
            </p>

            {/* Core Benefits */}
            <div className="mt-6">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Key Performance Outcomes
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {activeModalProgram.benefits.map((b, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-slate-300 bg-white/5 p-2.5 rounded-lg border border-white/5">
                    <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Equipment Utilized */}
            <div className="mt-6">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Equipment & Technology
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-400">
                {activeModalProgram.equipment.map((eq, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <Dumbbell className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{eq}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-400">
                <span className="text-slate-300 font-semibold">Lead Coach:</span> {activeModalProgram.trainerName}
              </div>
              <button
                onClick={() => {
                  const prog = activeModalProgram.title;
                  setActiveModalProgram(null);
                  onSelectProgramForPass(prog);
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-black font-bold text-sm shadow-lg shadow-amber-400/20 hover:scale-105 transition-all cursor-pointer"
              >
                Claim Free Session In This Program
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
