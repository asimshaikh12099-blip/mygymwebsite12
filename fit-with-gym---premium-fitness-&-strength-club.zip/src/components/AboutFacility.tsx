import React from 'react';
import { BUSINESS_INFO } from '../data/gymData';
import { 
  ShieldCheck, 
  Sparkles, 
  Flame, 
  Droplets, 
  Activity, 
  Coffee, 
  Key, 
  HeartHandshake, 
  Award,
  ArrowRight
} from 'lucide-react';

interface AboutFacilityProps {
  onOpenPassModal: () => void;
}

export const AboutFacility: React.FC<AboutFacilityProps> = ({ onOpenPassModal }) => {
  const amenities = [
    {
      icon: Award,
      title: 'Eleiko & Hammer Strength Arsenal',
      desc: 'Competition-certified power cages, calibrated steel plates, urethane dumbbells up to 150 lbs, and biomechanical selectorized machines.'
    },
    {
      icon: Droplets,
      title: 'Cedar Sauna & 45°F Cold Plunge',
      desc: 'Supercharge metabolic recovery, downregulate cortisol, and reduce inflammation with our daily contrast therapy thermal suites.'
    },
    {
      icon: Activity,
      title: 'InBody 570 Composition Scanner',
      desc: 'Track visceral fat, skeletal muscle mass, extracellular water ratios, and segmented lean analysis with medical-grade precision.'
    },
    {
      icon: Flame,
      title: '40-Yard Sprint Turf & Combat Zone',
      desc: 'High-density indoor turf equipped with Torque Tank power sleds, heavy boxing bags, assault bikes, and plyometric obstacles.'
    },
    {
      icon: Key,
      title: 'Luxury Locker & Rain Shower Suites',
      desc: 'Spacious private rain shower suites, keyless digital lockers, complimentary plush towels, and botanical hair & skin care.'
    },
    {
      icon: Coffee,
      title: 'Fuel Smoothie & Cold Brew Bar',
      desc: 'Refuel post-workout with micro-filtered whey and plant protein smoothies, clean electrolytes, and single-origin cold brew espresso.'
    }
  ];

  return (
    <section id="facility" className="py-20 lg:py-28 bg-[#0b0f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Story Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              About Fit With Gym
            </div>
            <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase leading-[0.98]">
              A TEMPLE OF <span className="text-gradient-gold">STRENGTH</span> & HUMAN POTENTIAL
            </h2>
            <p className="mt-6 text-base sm:text-lg text-slate-300 leading-relaxed">
              Founded on the belief that environment dictates results, <span className="text-white font-semibold">{BUSINESS_INFO.name}</span> was designed from the ground up to eliminate the distractions and frustrations of standard big-box gyms.
            </p>
            <p className="mt-4 text-base text-slate-400 leading-relaxed">
              Here, you will never wait 20 minutes for a squat rack or workout on broken equipment. We maintain a strict member-to-space ratio, invest continuously in world-class equipment, and provide an inspiring, respectful atmosphere where beginners feel empowered and seasoned athletes excel.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Cleanliness Guarantee</div>
                  <div className="text-xs text-slate-400">Sanitized continuously around the clock</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center text-amber-400">
                  <HeartHandshake className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm font-bold text-white">Supportive Community</div>
                  <div className="text-xs text-slate-400">No ego, high energy, genuine encouragement</div>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <button
                onClick={onOpenPassModal}
                className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-sm flex items-center gap-2 transition-all hover:scale-105 cursor-pointer"
              >
                <span>Tour Our Facility in Person</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>
            </div>
          </div>

          {/* Right Imagery Stack */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&w=1000&q=80"
                alt="Fit With Gym main strength zone and platforms"
                className="w-full h-[440px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f17] via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#0e1422]/90 backdrop-blur-md border border-white/10">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-display text-2xl font-bold text-white">16,500 SQ FT</div>
                    <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">Metropolis Main Campus</div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                    Open 24/7 RFID
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Amenities & Facility Perks Grid */}
        <div className="mt-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="font-display text-3xl sm:text-5xl font-bold text-white uppercase">
              PREMIUM <span className="text-gradient-gold">AMENITIES</span> INCLUDED
            </h3>
            <p className="mt-2 text-sm sm:text-base text-slate-300">
              Every detail has been carefully engineered for your comfort, recovery, and peak performance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {amenities.map((item, index) => {
              const IconComp = item.icon;
              return (
                <div
                  key={index}
                  className="glass-card p-6 rounded-2xl border border-white/10 group flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:bg-amber-400 group-hover:text-black transition-all">
                      <IconComp className="w-6 h-6" />
                    </div>
                    <h4 className="font-display text-2xl font-bold text-white mb-2">
                      {item.title}
                    </h4>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-white/5 flex items-center text-xs font-semibold text-amber-400">
                    <span>Included in Pro & VIP</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
