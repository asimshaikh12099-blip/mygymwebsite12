import React, { useState, useEffect } from 'react';
import { Menu, X, Dumbbell, Phone, Clock, MessageSquare, ChevronRight, Sparkles } from 'lucide-react';
import { BUSINESS_INFO } from '../data/gymData';

interface NavbarProps {
  onOpenPassModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenPassModal }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Programs', href: '#programs' },
    { label: 'Facility', href: '#facility' },
    { label: 'Schedule', href: '#schedule' },
    { label: 'Memberships', href: '#pricing' },
    { label: 'BMI Tool', href: '#calculator' },
    { label: 'Coaches', href: '#coaches' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ];

  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    "Hi Fit With Gym! I'd like to ask about memberships and book a free tour."
  )}`;

  return (
    <>
      {/* Top micro-announcement banner */}
      <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-black py-2 px-4 text-xs sm:text-sm font-semibold tracking-wide">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-black opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-black"></span>
            </span>
            <span>🔥 Autumn Pass: 3-Day Free All-Access Pass for Local Residents</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 opacity-90">
              <Clock className="w-3.5 h-3.5" />
              Open Today: {BUSINESS_INFO.hours.weekdays}
            </span>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="flex items-center gap-1 hover:underline font-bold"
            >
              <Phone className="w-3.5 h-3.5" />
              {BUSINESS_INFO.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Sticky Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0b0f17]/95 backdrop-blur-md border-b border-white/10 shadow-xl shadow-black/40 py-3.5'
            : 'bg-[#0b0f17]/80 backdrop-blur-sm border-b border-white/5 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform duration-300">
                <Dumbbell className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
              </div>
              <div className="flex flex-col">
                <span className="font-display text-2xl sm:text-3xl font-bold tracking-wider leading-none text-white group-hover:text-amber-400 transition-colors">
                  FIT WITH GYM
                </span>
                <span className="text-[10px] tracking-widest text-slate-400 font-medium uppercase mt-0.5">
                  Strength & Conditioning
                </span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-3 py-2 text-sm font-medium text-slate-300 hover:text-amber-400 hover:bg-white/5 rounded-lg transition-all"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Desktop Action Buttons */}
            <div className="hidden sm:flex items-center gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/30 text-[#25D366] text-sm font-semibold transition-all hover:scale-[1.02]"
                title="Chat with membership team on WhatsApp"
              >
                <MessageSquare className="w-4 h-4 fill-[#25D366]" />
                <span className="hidden xl:inline">WhatsApp</span>
              </a>

              <button
                onClick={onOpenPassModal}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-sm font-bold shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Claim Free Pass</span>
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex lg:hidden items-center gap-2">
              <button
                onClick={onOpenPassModal}
                className="px-3 py-1.5 rounded-lg bg-amber-400 text-black text-xs font-bold sm:hidden"
              >
                Free Pass
              </button>
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Toggle navigation menu"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => setIsOpen(false)}
          />

          {/* Drawer content */}
          <div className="fixed top-0 right-0 bottom-0 w-5/6 max-w-sm bg-[#0e1422] border-l border-white/10 p-6 flex flex-col justify-between shadow-2xl z-50 overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-6 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-amber-400 text-black flex items-center justify-center font-bold">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <span className="font-display text-2xl font-bold tracking-wider text-white">
                    FIT WITH GYM
                  </span>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation links */}
              <nav className="flex flex-col gap-1 py-6">
                {navLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="flex items-center justify-between px-4 py-3 rounded-xl text-slate-200 hover:text-amber-400 hover:bg-white/5 font-medium transition-colors"
                  >
                    <span>{link.label}</span>
                    <ChevronRight className="w-4 h-4 text-slate-500" />
                  </a>
                ))}
              </nav>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 border-t border-white/10 flex flex-col gap-3">
              <button
                onClick={() => {
                  setIsOpen(false);
                  onOpenPassModal();
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-black font-bold text-center shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                Claim 3-Day Free Pass
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 text-[#25D366] font-semibold text-center flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4 fill-[#25D366]" />
                WhatsApp Membership Desk
              </a>

              <div className="text-center pt-2 text-xs text-slate-400">
                <p>📍 {BUSINESS_INFO.address}</p>
                <p className="mt-1">📞 {BUSINESS_INFO.phone}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
