import React from 'react';
import { ArrowRight, ShieldCheck, Flame, Users, Award, Clock, Sparkles, CheckCircle2 } from 'lucide-react';
import { BUSINESS_INFO } from '../data/gymData';

interface HeroProps {
  onOpenPassModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenPassModal }) => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-8 pb-16 sm:py-20 lg:py-28">
      {/* Background with layered gradient overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=2000&q=85"
          alt="Fit With Gym main floor with Olympic barbells and strength training rigs"
          className="w-full h-full object-cover object-center scale-105 filter brightness-[0.35] contrast-[1.1]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f17] via-[#0b0f17]/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0f17] via-[#0b0f17]/60 to-transparent" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-amber-500/10 rounded-full blur-[140px] pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          {/* Status badge & top eyebrow */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 backdrop-blur-md mb-6">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs sm:text-sm font-medium text-slate-200">
              Open Now • Closes at 11:00 PM
            </span>
            <span className="text-white/20">|</span>
            <span className="text-xs sm:text-sm font-semibold text-amber-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> Metropolis Premier Club
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="font-display text-5xl sm:text-7xl lg:text-8xl font-bold tracking-tight text-white leading-[0.95] uppercase">
            FORGE YOUR <br />
            <span className="text-gradient-gold">STRONGEST</span> SELF
          </h1>

          {/* Subheading */}
          <p className="mt-6 text-lg sm:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl">
            Welcome to <span className="text-white font-semibold">{BUSINESS_INFO.name}</span> — the ultimate intersection of elite strength conditioning, metabolic interval training, and luxury thermal recovery. Built for those who refuse average.
          </p>

          {/* Key Quick Benefit Badges */}
          <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-xs sm:text-sm text-slate-300">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              Zero Lock-In Contracts
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              Free InBody 570 Scan
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              Cedar Sauna & Cold Plunge
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
              24/7 Keycard Access
            </span>
          </div>

          {/* Dual CTAs */}
          <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              onClick={onOpenPassModal}
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-base tracking-wide flex items-center justify-center gap-3 shadow-xl shadow-amber-500/25 hover:shadow-amber-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer group"
            >
              <span>CLAIM FREE 3-DAY PASS</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>

            <a
              href="#programs"
              className="px-7 py-4 rounded-xl glass-panel text-white hover:text-amber-300 hover:border-amber-400/40 font-semibold text-base flex items-center justify-center gap-2 hover:bg-white/10 transition-all text-center"
            >
              <span>Explore Programs</span>
            </a>
          </div>

          {/* Social Proof Quote Micro-banner */}
          <div className="mt-10 pt-6 border-t border-white/10 flex items-center gap-4">
            <div className="flex -space-x-2 overflow-hidden">
              <img
                className="inline-block h-10 w-10 rounded-full ring-2 ring-[#0b0f17] object-cover"
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80"
                alt="Member"
              />
              <img
                className="inline-block h-10 w-10 rounded-full ring-2 ring-[#0b0f17] object-cover"
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80"
                alt="Member"
              />
              <img
                className="inline-block h-10 w-10 rounded-full ring-2 ring-[#0b0f17] object-cover"
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80"
                alt="Member"
              />
            </div>
            <div>
              <div className="flex items-center gap-1 text-amber-400 text-sm">
                {'★'.repeat(5)}
                <span className="ml-1 text-white font-bold">4.9 / 5.0</span>
              </div>
              <p className="text-xs text-slate-400">
                Over 1,200+ local members training with peak confidence
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Key Stats Bar across bottom */}
      <div className="absolute bottom-0 inset-x-0 bg-[#0e1422]/90 backdrop-blur-md border-t border-white/10 py-4 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-4 divide-x divide-white/10 text-center">
            <div className="px-4">
              <div className="font-display text-3xl font-bold text-amber-400">{BUSINESS_INFO.stats.sqft}</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider mt-0.5">Sq Ft Athletic Floor</div>
            </div>
            <div className="px-4">
              <div className="font-display text-3xl font-bold text-white">{BUSINESS_INFO.stats.classesWeekly}</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider mt-0.5">Weekly Group Classes</div>
            </div>
            <div className="px-4">
              <div className="font-display text-3xl font-bold text-amber-400">{BUSINESS_INFO.stats.coaches}</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider mt-0.5">Certified Master Coaches</div>
            </div>
            <div className="px-4">
              <div className="font-display text-3xl font-bold text-white">24/7</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider mt-0.5">Biometric RFID Access</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
