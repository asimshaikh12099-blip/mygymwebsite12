import React, { useState } from 'react';
import { PRICING_PLANS, BUSINESS_INFO } from '../data/gymData';
import { Check, Sparkles, Shield, ArrowRight, HelpCircle } from 'lucide-react';

interface PricingProps {
  onSelectPlan: (planName: string) => void;
}

export const Pricing: React.FC<PricingProps> = ({ onSelectPlan }) => {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="py-20 lg:py-28 bg-[#0b0f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Simple, Transparent Memberships
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            INVEST IN YOUR <span className="text-gradient-gold">HEALTH & STRENGTH</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            No sneaky lock-ins. No hidden cancellation penalties. Pure performance and premium facilities.
          </p>

          {/* Monthly / Annual Toggle */}
          <div className="mt-8 inline-flex items-center p-1.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                !isAnnual
                  ? 'bg-amber-400 text-black shadow-md shadow-amber-400/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isAnnual
                  ? 'bg-amber-400 text-black shadow-md shadow-amber-400/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Annual Billing</span>
              <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-black text-amber-400">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {PRICING_PLANS.map((plan) => {
            const price = isAnnual ? plan.annualPrice : plan.monthlyPrice;
            const isDropIn = plan.id === 'plan-day';

            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl flex flex-col justify-between transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-b from-[#1a2336] to-[#121927] border-2 border-amber-400 shadow-2xl shadow-amber-500/20 lg:-translate-y-3'
                    : 'glass-card border border-white/10 hover:border-white/20'
                } p-6 sm:p-7`}
              >
                {/* Popular / Badge Banner */}
                {plan.badge && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span
                      className={`px-3.5 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider shadow-md ${
                        plan.popular
                          ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black shadow-amber-400/30'
                          : 'bg-white/15 text-slate-200 border border-white/15'
                      }`}
                    >
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div>
                  <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase tracking-wide">
                    {plan.name}
                  </h3>
                  <p className="mt-1 text-xs text-slate-400 min-h-[32px]">
                    {plan.subtitle}
                  </p>

                  {/* Price display */}
                  <div className="mt-5 pb-5 border-b border-white/10">
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-bold text-amber-400">$</span>
                      <span className="font-display text-5xl font-bold text-white tracking-tight">
                        {price}
                      </span>
                      <span className="text-xs text-slate-400">
                        {isDropIn ? '/ day' : '/ month'}
                      </span>
                    </div>
                    {!isDropIn && isAnnual && (
                      <p className="text-[11px] text-emerald-400 font-semibold mt-1">
                        Billed annually (Save ${(plan.monthlyPrice - plan.annualPrice) * 12}/yr)
                      </p>
                    )}
                  </div>

                  {/* Feature Checklist */}
                  <ul className="mt-6 space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <div
                          className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                            plan.popular ? 'bg-amber-400 text-black' : 'bg-white/10 text-amber-400'
                          }`}
                        >
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                        <span className="leading-snug">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Bottom CTA */}
                <div className="mt-8 pt-4">
                  <button
                    onClick={() => onSelectPlan(plan.name)}
                    className={`w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      plan.popular
                        ? 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black shadow-lg shadow-amber-400/25 hover:scale-[1.02]'
                        : 'bg-white/10 hover:bg-white/20 text-white border border-white/15'
                    }`}
                  >
                    <span>{plan.ctaText}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Guarantee Banner */}
        <div className="mt-12 glass-panel p-6 rounded-2xl border border-white/10 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">14-Day 100% Satisfaction Guarantee</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                If you aren't completely thrilled with your Fit With Gym experience within 14 days, we will refund your membership in full. No questions asked.
              </p>
            </div>
          </div>
          <a
            href={`https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
              "Hi! I'd like to ask a few questions regarding membership plans."
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-amber-400 text-xs font-semibold whitespace-nowrap border border-white/10"
          >
            Ask Questions on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
};
