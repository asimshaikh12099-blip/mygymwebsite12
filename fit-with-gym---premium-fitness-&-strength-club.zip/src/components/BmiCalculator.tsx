import React, { useState } from 'react';
import { Calculator, Flame, Activity, ArrowRight, Sparkles, RefreshCw } from 'lucide-react';

interface BmiCalculatorProps {
  onRecommendProgram: (programName: string) => void;
}

export const BmiCalculator: React.FC<BmiCalculatorProps> = ({ onRecommendProgram }) => {
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState<number>(28);
  const [heightCm, setHeightCm] = useState<number>(175);
  const [heightFt, setHeightFt] = useState<number>(5);
  const [heightIn, setHeightIn] = useState<number>(9);
  const [weightKg, setWeightKg] = useState<number>(75);
  const [weightLbs, setWeightLbs] = useState<number>(165);
  const [activity, setActivity] = useState<number>(1.55); // 1.2, 1.375, 1.55, 1.725
  const [goal, setGoal] = useState<'loss' | 'muscle' | 'strength' | 'health'>('muscle');

  // Calculations
  const calculatedHeightCm = unit === 'metric' ? heightCm : (heightFt * 12 + heightIn) * 2.54;
  const calculatedWeightKg = unit === 'metric' ? weightKg : weightLbs * 0.453592;

  const heightInMeters = calculatedHeightCm / 100;
  const bmi = heightInMeters > 0 ? calculatedWeightKg / (heightInMeters * heightInMeters) : 0;
  const roundedBmi = Number(bmi.toFixed(1));

  // Mifflin-St Jeor Formula
  // Male: 10 * weight(kg) + 6.25 * height(cm) - 5 * age + 5
  // Female: 10 * weight(kg) + 6.25 * height(cm) - 5 * age - 161
  let bmr = 10 * calculatedWeightKg + 6.25 * calculatedHeightCm - 5 * age;
  bmr = gender === 'male' ? bmr + 5 : bmr - 161;
  const tdee = Math.round(bmr * activity);

  // Target calories based on goal
  let targetCalories = tdee;
  let recommendedProgram = 'Hypertrophy & Strength Lab';
  if (goal === 'loss') {
    targetCalories = Math.round(tdee - 500);
    recommendedProgram = 'Metabolic Ignite HIIT';
  } else if (goal === 'muscle') {
    targetCalories = Math.round(tdee + 300);
    recommendedProgram = 'Hypertrophy & Strength Lab';
  } else if (goal === 'strength') {
    targetCalories = Math.round(tdee + 200);
    recommendedProgram = 'Functional Athletic Performance';
  } else {
    targetCalories = tdee;
    recommendedProgram = 'Vinyasa Flow & Thermal Mobility';
  }

  // Protein target (~2.0g per kg bodyweight)
  const proteinGrams = Math.round(calculatedWeightKg * 2.0);

  // BMI Category
  const getBmiCategory = (val: number) => {
    if (val < 18.5) return { label: 'Underweight', color: 'text-sky-400', barPos: '15%' };
    if (val < 25) return { label: 'Optimal / Athletic Normal', color: 'text-emerald-400', barPos: '45%' };
    if (val < 30) return { label: 'Overweight', color: 'text-amber-400', barPos: '75%' };
    return { label: 'High Body Mass', color: 'text-rose-400', barPos: '95%' };
  };

  const bmiCat = getBmiCategory(roundedBmi);

  return (
    <section id="calculator" className="py-20 lg:py-28 bg-[#0e1422] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Calculator className="w-3.5 h-3.5" />
            Interactive Health & Performance Metric
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            BODY MASS & <span className="text-gradient-gold">CALORIC ENGINE</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            Calculate your clinical BMI, basal metabolic rate, and daily caloric targets tailored to your primary fitness aspiration.
          </p>
        </div>

        {/* Calculator Widget Grid */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Inputs Column */}
          <div className="lg:col-span-7 glass-card p-6 sm:p-8 rounded-2xl border border-white/10 space-y-6">
            {/* Unit & Gender Toggles */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">Unit System:</span>
                <div className="p-1 rounded-xl bg-white/5 border border-white/10 flex">
                  <button
                    onClick={() => setUnit('metric')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold ${
                      unit === 'metric' ? 'bg-amber-400 text-black' : 'text-slate-400'
                    }`}
                  >
                    Metric (cm/kg)
                  </button>
                  <button
                    onClick={() => setUnit('imperial')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold ${
                      unit === 'imperial' ? 'bg-amber-400 text-black' : 'text-slate-400'
                    }`}
                  >
                    Imperial (ft/lbs)
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">Biological Sex:</span>
                <div className="p-1 rounded-xl bg-white/5 border border-white/10 flex">
                  <button
                    onClick={() => setGender('male')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold ${
                      gender === 'male' ? 'bg-amber-400 text-black' : 'text-slate-400'
                    }`}
                  >
                    Male
                  </button>
                  <button
                    onClick={() => setGender('female')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold ${
                      gender === 'female' ? 'bg-amber-400 text-black' : 'text-slate-400'
                    }`}
                  >
                    Female
                  </button>
                </div>
              </div>
            </div>

            {/* Age, Height, Weight inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Age (years)
                </label>
                <input
                  type="number"
                  min="14"
                  max="95"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-semibold text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              {unit === 'metric' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Height (cm)
                  </label>
                  <input
                    type="number"
                    min="100"
                    max="240"
                    value={heightCm}
                    onChange={(e) => setHeightCm(Number(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-semibold text-sm focus:outline-none focus:border-amber-400"
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Feet
                    </label>
                    <input
                      type="number"
                      min="3"
                      max="7"
                      value={heightFt}
                      onChange={(e) => setHeightFt(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-semibold text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Inches
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="11"
                      value={heightIn}
                      onChange={(e) => setHeightIn(Number(e.target.value))}
                      className="w-full px-3 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-semibold text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Weight ({unit === 'metric' ? 'kg' : 'lbs'})
                </label>
                <input
                  type="number"
                  min="30"
                  max="250"
                  value={unit === 'metric' ? weightKg : weightLbs}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    if (unit === 'metric') setWeightKg(val);
                    else setWeightLbs(val);
                  }}
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white font-semibold text-sm focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Activity Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Current Physical Activity Level
              </label>
              <select
                value={activity}
                onChange={(e) => setActivity(Number(e.target.value))}
                aria-label="Current Physical Activity Level"
                className="w-full px-4 py-2.5 rounded-xl bg-[#141b2a] border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value={1.2}>Sedentary (Desk job, little to no structured workout)</option>
                <option value={1.375}>Light Exercise (1 - 2 gym sessions / week)</option>
                <option value={1.55}>Moderately Active (3 - 5 intense training sessions / week)</option>
                <option value={1.725}>Very Active (6 - 7 sessions / week or heavy labor)</option>
              </select>
            </div>

            {/* Goal Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Primary Transformation Goal
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'loss', label: 'Fat Loss', desc: '500 kcal deficit' },
                  { id: 'muscle', label: 'Lean Bulk', desc: '300 kcal surplus' },
                  { id: 'strength', label: 'Raw Strength', desc: 'Performance maintenance' },
                  { id: 'health', label: 'General Health', desc: 'Total body balance' },
                ].map((g) => (
                  <button
                    key={g.id}
                    onClick={() => setGoal(g.id as any)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      goal === g.id
                        ? 'bg-amber-400/10 border-amber-400 text-white'
                        : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs text-white">{g.label}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">{g.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results Summary Column */}
          <div className="lg:col-span-5 glass-panel p-6 sm:p-8 rounded-2xl border border-white/15 relative">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <span className="text-xs uppercase font-bold text-amber-400 tracking-wider">
                Personalized Assessment
              </span>
              <span className="text-xs text-slate-400">Clinical Formulas</span>
            </div>

            {/* BMI Number Card */}
            <div className="mt-6 text-center">
              <span className="text-xs text-slate-400 uppercase tracking-widest">
                Body Mass Index (BMI)
              </span>
              <div className="font-display text-6xl sm:text-7xl font-bold text-white mt-1">
                {roundedBmi}
              </div>
              <div className={`text-sm font-bold mt-1 ${bmiCat.color}`}>
                {bmiCat.label}
              </div>

              {/* BMI visual meter bar */}
              <div className="mt-4 w-full bg-white/10 h-2.5 rounded-full overflow-hidden relative">
                <div
                  className="h-full bg-gradient-to-r from-sky-400 via-emerald-400 to-rose-400 rounded-full"
                  style={{ width: '100%' }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>&lt; 18.5 Lean</span>
                <span>18.5 - 24.9 Athletic</span>
                <span>25 - 29.9 Heavy</span>
                <span>30+ High</span>
              </div>
            </div>

            {/* Daily Energy & Macro Card */}
            <div className="mt-6 grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-[11px] text-slate-400 uppercase font-semibold">
                  Basal BMR
                </div>
                <div className="font-display text-2xl font-bold text-white mt-0.5">
                  {Math.round(bmr)} <span className="text-xs text-slate-400 font-sans">kcal</span>
                </div>
                <div className="text-[10px] text-slate-400">Base burn at rest</div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-center">
                <div className="text-[11px] text-slate-400 uppercase font-semibold">
                  Daily Target Cal
                </div>
                <div className="font-display text-2xl font-bold text-amber-400 mt-0.5">
                  {targetCalories} <span className="text-xs text-slate-400 font-sans">kcal</span>
                </div>
                <div className="text-[10px] text-slate-400">For selected goal</div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-center col-span-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Daily Protein Blueprint:</span>
                  <span className="font-bold text-white">{proteinGrams}g / day</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 text-left">
                  Targets 2.0g per kg bodyweight to preserve lean muscular mass during training.
                </p>
              </div>
            </div>

            {/* Recommended Program */}
            <div className="mt-6 pt-5 border-t border-white/10">
              <div className="text-[11px] text-amber-400 font-bold uppercase tracking-wider mb-1">
                Recommended Fit With Gym Program:
              </div>
              <div className="font-display text-2xl font-bold text-white">
                {recommendedProgram}
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Optimized programming designed specifically for your metabolic profile and goal.
              </p>
              <button
                onClick={() => onRecommendProgram(recommendedProgram)}
                className="mt-4 w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-400/20 cursor-pointer"
              >
                <span>Book Free Trial For This Program</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
