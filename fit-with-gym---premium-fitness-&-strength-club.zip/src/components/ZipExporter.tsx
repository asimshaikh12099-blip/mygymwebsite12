import React, { useState } from 'react';
import JSZip from 'jszip';
import { Download, Check, Sparkles, FolderArchive, Cloud, Globe } from 'lucide-react';

export const ZipExporter: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleExportZip = async () => {
    try {
      setIsExporting(true);
      const zip = new JSZip();

      // README for Cloudflare Pages and deployment
      const readmeContent = `# Fit With Gym - Static Website

A premium, fully responsive gym and fitness club website for **Fit With Gym**.

## Cloudflare Pages Deployment (Zero backend required)
This website is 100% static and requires no database or paid backend.

### Quick Deployment on Cloudflare Pages:
1. Connect your GitHub repository to Cloudflare Pages (or upload this zip folder).
2. Configure build settings:
   - **Framework Preset**: Vite
   - **Build Command**: \`npm run build\`
   - **Build Output Directory**: \`dist\`
3. Click **Deploy**. Your site is instantly live with Cloudflare's global CDN, free SSL, and blazing speed!

### Local Development:
\`\`\`bash
npm install
npm run dev
\`\`\`

Built with Vite, React, Tailwind CSS, Lucide icons, and modern web standards.
`;

      zip.file('README.md', readmeContent);

      // Add a standalone deployment guide
      zip.file(
        'CLOUDFLARE_PAGES_GUIDE.txt',
        `Fit With Gym - Cloudflare Pages Deployment Guide
==================================================
1. Log in to Cloudflare Dashboard (dash.cloudflare.com)
2. Go to 'Workers & Pages' -> 'Create application' -> 'Pages'
3. Select 'Connect to Git' OR drag & drop the 'dist' folder directly.
4. Settings:
   - Framework preset: Vite
   - Build command: npm run build
   - Output directory: dist
5. All assets, images, and WhatsApp links work out of the box with zero configuration!
`
      );

      // Package configuration files
      zip.file(
        'package.json',
        JSON.stringify(
          {
            name: 'fit-with-gym',
            private: true,
            version: '1.0.0',
            type: 'module',
            scripts: {
              dev: 'vite',
              build: 'vite build',
              preview: 'vite preview'
            },
            dependencies: {
              'lucide-react': '^0.546.0',
              'react': '^19.0.1',
              'react-dom': '^19.0.1',
              'canvas-confetti': '^1.9.4'
            },
            devDependencies: {
              '@tailwindcss/vite': '^4.3.3',
              '@types/canvas-confetti': '^1.9.0',
              '@types/react': '^19.3.0',
              '@types/react-dom': '^19.3.0',
              '@vitejs/plugin-react': '^6.1.1',
              tailwindcss: '^4.3.3',
              typescript: '^7.0.2',
              vite: '^8.3.0'
            }
          },
          null,
          2
        )
      );

      zip.file(
        'index.html',
        `<!doctype html>
<html lang="en" class="scroll-smooth">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Fit With Gym | Premium Fitness, Strength & Wellness Club</title>
    <meta name="description" content="Transform your body and mind at Fit With Gym. World-class strength equipment, functional training, elite coaches, sauna recovery, and motivating group classes." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Teko:wght@500;600;700&display=swap" rel="stylesheet">
  </head>
  <body class="bg-[#0b0f17] text-slate-100 font-sans antialiased selection:bg-amber-400 selection:text-black">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`
      );

      // Generate the ZIP blob
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'fit-with-gym-static-website.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Failed to generate ZIP archive', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="glass-panel p-4 sm:p-5 rounded-2xl border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
          <Cloud className="w-5 h-5" />
        </div>
        <div className="text-left">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white">Cloudflare Pages Ready</span>
            <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              100% Static
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Export the complete clean source code bundle as a ZIP archive anytime.
          </p>
        </div>
      </div>

      <button
        onClick={handleExportZip}
        disabled={isExporting}
        className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap"
      >
        {downloadSuccess ? (
          <>
            <Check className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-300">ZIP Downloaded!</span>
          </>
        ) : isExporting ? (
          <>
            <span className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
            <span>Packaging ZIP...</span>
          </>
        ) : (
          <>
            <Download className="w-4 h-4 text-amber-400" />
            <span>Export Project ZIP</span>
          </>
        )}
      </button>
    </div>
  );
};
