import React, { useState } from 'react';
import { BUSINESS_INFO } from '../data/gymData';
import { MapPin, Phone, Mail, Clock, MessageSquare, Send, CheckCircle2, Car, Navigation } from 'lucide-react';
import confetti from 'canvas-confetti';

export const ContactSection: React.FC = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    serviceInterest: 'Facility Tour & Free Pass',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;

    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.8 }
    });

    setFormSubmitted(true);
  };

  const whatsappInquiryUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    `Hi Fit With Gym! My name is ${formData.name || 'Member'}. I would like to schedule a tour and inquiry regarding ${formData.serviceInterest}.`
  )}`;

  return (
    <section id="contact" className="py-20 lg:py-28 bg-[#0b0f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <MapPin className="w-3.5 h-3.5" />
            Connect & Visit
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            VISIT OUR <span className="text-gradient-gold">FACILITY</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            Drop by for a coffee and private tour, or send us a message. Our team is ready to welcome you.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="mt-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Contact Info & Hours */}
          <div className="lg:col-span-5 space-y-6">
            {/* Quick Cards */}
            <div className="glass-card p-6 rounded-2xl border border-white/10 space-y-4">
              <h3 className="font-display text-2xl font-bold text-white uppercase">
                Club Information
              </h3>

              <div className="flex items-start gap-3.5 text-sm text-slate-300">
                <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-white">Location Address</div>
                  <p className="text-xs text-slate-400 mt-0.5">{BUSINESS_INFO.address}</p>
                  <p className="text-xs text-slate-400">{BUSINESS_INFO.city}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 text-sm text-slate-300">
                <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-white">Operating Hours</div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    <strong>Mon - Fri:</strong> {BUSINESS_INFO.hours.weekdays}
                  </p>
                  <p className="text-xs text-slate-300">
                    <strong>Sat - Sun:</strong> {BUSINESS_INFO.hours.weekends}
                  </p>
                  <p className="text-[11px] text-emerald-400 font-semibold mt-1">
                    ⚡ {BUSINESS_INFO.hours.twentyFourSeven}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 text-sm text-slate-300">
                <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-white">Phone & Concierge</div>
                  <a
                    href={`tel:${BUSINESS_INFO.phone}`}
                    className="text-xs text-amber-400 hover:underline block mt-0.5 font-semibold"
                  >
                    {BUSINESS_INFO.phone}
                  </a>
                  <a
                    href={`mailto:${BUSINESS_INFO.email}`}
                    className="text-xs text-slate-400 hover:underline block"
                  >
                    {BUSINESS_INFO.email}
                  </a>
                </div>
              </div>
            </div>

            {/* Direct WhatsApp Callout */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#1b3d2b] to-[#12241b] border border-[#25D366]/30 flex items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#25D366]">
                  Instant WhatsApp Desk
                </span>
                <h4 className="font-display text-2xl font-bold text-white">
                  Chat With A Coach Now
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Get answers within minutes regarding memberships & schedule.
                </p>
              </div>
              <a
                href={`https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
                  "Hi Fit With Gym! I'm interested in booking a visit today."
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full bg-[#25D366] text-black flex items-center justify-center shrink-0 hover:scale-110 transition-transform shadow-lg shadow-[#25D366]/20"
                aria-label="Open WhatsApp Chat"
              >
                <MessageSquare className="w-6 h-6 fill-black" />
              </a>
            </div>

            {/* Transit & Parking badge */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3 text-xs text-slate-300">
              <Car className="w-5 h-5 text-amber-400 shrink-0" />
              <span>Complimentary 2-hour validated parking for members in the underground garage.</span>
            </div>
          </div>

          {/* Right: Interactive Message & Tour Request Form */}
          <div className="lg:col-span-7 glass-card p-6 sm:p-8 rounded-2xl border border-white/10">
            {!formSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase">
                  Schedule A Visit / Send A Message
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  Fill in your details and our team will get in touch to confirm your visit time.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Jordan Reed"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Phone Number (WhatsApp) *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="jordan@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Area of Interest
                    </label>
                    <select
                      value={formData.serviceInterest}
                      onChange={(e) => setFormData({ ...formData, serviceInterest: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#141b2a] border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400 cursor-pointer"
                    >
                      <option>Facility Tour & Free Pass</option>
                      <option>Strength & Hypertrophy Program</option>
                      <option>Metabolic Ignite HIIT Classes</option>
                      <option>1-on-1 Personal Coaching</option>
                      <option>Sauna & Recovery Spa Access</option>
                      <option>Corporate Team Membership</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Fitness Goals or Questions (Optional)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Tell us about your background, any past injuries, or specific questions..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400 resize-none"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    type="submit"
                    className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 cursor-pointer transition-all"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Tour Request</span>
                  </button>

                  <a
                    href={whatsappInquiryUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-5 py-3.5 rounded-xl bg-[#25D366]/20 border border-[#25D366]/40 text-[#25D366] font-bold text-sm flex items-center justify-center gap-2 hover:bg-[#25D366]/30 transition-all text-center"
                  >
                    <MessageSquare className="w-4 h-4 fill-[#25D366]" />
                    <span>Send via WhatsApp</span>
                  </a>
                </div>
              </form>
            ) : (
              <div className="py-12 text-center">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="font-display text-3xl font-bold text-white uppercase">
                  Message Received!
                </h4>
                <p className="mt-2 text-sm text-slate-300 max-w-md mx-auto">
                  Thank you, <strong className="text-white">{formData.name}</strong>. Our front desk concierge has logged your tour request for <strong className="text-amber-400">{formData.serviceInterest}</strong> and will reach out via WhatsApp / phone shortly.
                </p>

                <div className="mt-6 flex justify-center gap-3">
                  <a
                    href={whatsappInquiryUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 rounded-xl bg-[#25D366] text-black font-bold text-xs flex items-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4 fill-black" />
                    Open Chat On WhatsApp
                  </a>
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({ name: '', email: '', phone: '', serviceInterest: 'Facility Tour & Free Pass', message: '' });
                    }}
                    className="px-4 py-3 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/15"
                  >
                    Send Another
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
