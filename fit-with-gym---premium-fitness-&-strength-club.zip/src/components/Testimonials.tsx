import React from 'react';
import { TESTIMONIALS } from '../data/gymData';
import { Star, Quote, Award, Sparkles, CheckCircle } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 lg:py-28 bg-[#0b0f17] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            Real Transformations
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            HEAR FROM OUR <span className="text-gradient-gold">ATHLETIC COMMUNITY</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            Real members. Consistent discipline. Measurable transformations inside and outside the weight room.
          </p>
        </div>

        {/* Rating Score Banner */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-center">
          <div className="glass-panel px-6 py-3 rounded-2xl border border-white/10 flex items-center gap-4">
            <div className="font-display text-4xl font-bold text-amber-400">4.9</div>
            <div className="text-left">
              <div className="flex text-amber-400 text-sm">
                {'★'.repeat(5)}
              </div>
              <div className="text-xs text-slate-400">Over 380+ Verified Local Member Reviews</div>
            </div>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="glass-card p-6 sm:p-7 rounded-2xl border border-white/10 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex text-amber-400 text-sm">
                    {Array.from({ length: item.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-6 h-6 text-white/10" />
                </div>

                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-400/10 text-amber-300 text-xs font-bold mb-4">
                  <Award className="w-3.5 h-3.5" />
                  {item.achievement}
                </div>

                <p className="text-sm text-slate-300 leading-relaxed italic">
                  "{item.review}"
                </p>
              </div>

              {/* Author footer */}
              <div className="mt-6 pt-5 border-t border-white/10 flex items-center gap-3">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-400/30"
                />
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1">
                    {item.name}
                    <CheckCircle className="w-3.5 h-3.5 text-amber-400" />
                  </h4>
                  <p className="text-xs text-slate-400">{item.role}</p>
                  <p className="text-[10px] text-amber-400/80 mt-0.5">{item.memberSince}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
