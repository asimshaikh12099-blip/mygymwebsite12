import React, { useState } from 'react';
import { SCHEDULE_ITEMS, BUSINESS_INFO } from '../data/gymData';
import { ClassScheduleItem } from '../types';
import { Calendar, Clock, MapPin, User, Flame, CheckCircle, AlertCircle, X, Sparkles, Send } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ScheduleProps {
  onOpenPassModal: () => void;
}

export const Schedule: React.FC<ScheduleProps> = ({ onOpenPassModal }) => {
  const days: ('Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday')[] = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
  ];

  const [activeDay, setActiveDay] = useState<typeof days[number]>('Monday');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [bookingClass, setBookingClass] = useState<ClassScheduleItem | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState<boolean>(false);
  const [bookingForm, setBookingForm] = useState({ name: '', phone: '', email: '' });

  const categories = [
    { id: 'all', label: 'All Classes' },
    { id: 'strength', label: 'Strength' },
    { id: 'hiit', label: 'HIIT' },
    { id: 'functional', label: 'Functional' },
    { id: 'mobility', label: 'Mobility & Yoga' },
    { id: 'boxing', label: 'Boxing' },
    { id: 'spin', label: 'Cycle Spin' },
  ];

  const filteredClasses = SCHEDULE_ITEMS.filter((item) => {
    const matchDay = item.day === activeDay;
    const matchCat = activeCategory === 'all' || item.category === activeCategory;
    return matchDay && matchCat;
  });

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingForm.name || !bookingForm.phone) return;

    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.7 }
    });

    setBookingSuccess(true);
  };

  const handleCloseModal = () => {
    setBookingClass(null);
    setBookingSuccess(false);
    setBookingForm({ name: '', phone: '', email: '' });
  };

  return (
    <section id="schedule" className="py-20 lg:py-28 bg-[#0e1422] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold uppercase tracking-widest mb-4">
            <Calendar className="w-3.5 h-3.5" />
            Live Class Timetable
          </div>
          <h2 className="font-display text-4xl sm:text-6xl font-bold tracking-tight text-white uppercase">
            WEEKLY <span className="text-gradient-gold">CLASS SCHEDULE</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300">
            Over 55 dynamic coach-led sessions every week. Free first class included with your 3-Day Pass!
          </p>
        </div>

        {/* Day Selector Tabs */}
        <div className="mt-10 flex overflow-x-auto pb-2 scrollbar-none justify-start sm:justify-center gap-2">
          {days.map((day) => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`px-4 sm:px-6 py-3 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
                activeDay === day
                  ? 'bg-amber-400 text-black shadow-lg shadow-amber-400/20 scale-105'
                  : 'bg-white/5 text-slate-300 hover:text-white hover:bg-white/10 border border-white/5'
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        {/* Category Pill Filters */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCategory(c.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeCategory === c.id
                  ? 'bg-white/20 text-amber-400 border border-amber-400/40'
                  : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Classes Table / Card View */}
        <div className="mt-10 space-y-3">
          {filteredClasses.length === 0 ? (
            <div className="glass-panel p-12 text-center rounded-2xl border border-white/10">
              <AlertCircle className="w-10 h-10 text-amber-400 mx-auto mb-3" />
              <p className="text-lg font-bold text-white">No classes scheduled in this filter</p>
              <p className="text-sm text-slate-400 mt-1">
                Select another category or browse open gym hours.
              </p>
            </div>
          ) : (
            filteredClasses.map((item) => {
              const spotsLeft = item.capacity - item.bookedCount;
              const isNearlyFull = spotsLeft <= 3;

              return (
                <div
                  key={item.id}
                  className="glass-card p-4 sm:p-5 rounded-2xl border border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all"
                >
                  {/* Time & Duration */}
                  <div className="flex items-center gap-4 min-w-[190px]">
                    <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 flex flex-col items-center justify-center text-amber-400">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-base sm:text-lg font-bold text-white tracking-wide">
                        {item.time}
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1">
                        <span>{item.duration}</span>
                        <span>•</span>
                        <span className="text-amber-400 font-medium">{item.intensity} Intensity</span>
                      </div>
                    </div>
                  </div>

                  {/* Title & Room */}
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                        {item.title}
                      </h3>
                      <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-slate-300 text-[11px] font-semibold uppercase">
                        {item.category}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 mt-1.5 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-amber-400" />
                        Coach: <strong className="text-slate-200">{item.instructor}</strong>
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {item.room}
                      </span>
                    </div>
                  </div>

                  {/* Spots & CTA */}
                  <div className="w-full md:w-auto flex items-center justify-between md:justify-end gap-4 pt-3 md:pt-0 border-t md:border-t-0 border-white/10">
                    <div className="text-right">
                      <div className="text-xs text-slate-400">
                        Capacity: {item.bookedCount}/{item.capacity}
                      </div>
                      <div
                        className={`text-xs font-bold ${
                          isNearlyFull ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        {spotsLeft > 0 ? `${spotsLeft} Spots Remaining` : 'Waitlist Only'}
                      </div>
                    </div>

                    <button
                      onClick={() => setBookingClass(item)}
                      className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold transition-all shadow-md shadow-amber-400/20 hover:scale-105 cursor-pointer whitespace-nowrap"
                    >
                      Reserve Spot
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Schedule Bottom Note */}
        <div className="mt-8 text-center text-xs sm:text-sm text-slate-400 flex flex-wrap items-center justify-center gap-2">
          <span>Need a customized corporate or private group session?</span>
          <a
            href={`https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
              'Hi Fit With Gym! I would like to inquire about private group bookings or corporate schedule.'
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-amber-400 hover:underline font-semibold"
          >
            Message Coach Concierge on WhatsApp →
          </a>
        </div>
      </div>

      {/* Class Reservation Modal */}
      {bookingClass && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={handleCloseModal}
          />

          <div className="relative w-full max-w-lg bg-[#121927] border border-white/15 rounded-2xl p-6 sm:p-8 shadow-2xl z-10">
            <button
              onClick={handleCloseModal}
              className="absolute top-5 right-5 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {!bookingSuccess ? (
              <>
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
                  <Sparkles className="w-4 h-4" />
                  Instant Class Reservation
                </div>

                <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase">
                  {bookingClass.title}
                </h3>

                <div className="mt-3 p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs space-y-1 text-slate-300">
                  <p>📅 <strong>Day & Time:</strong> {bookingClass.day} at {bookingClass.time} ({bookingClass.duration})</p>
                  <p>🏋️ <strong>Coach:</strong> {bookingClass.instructor}</p>
                  <p>📍 <strong>Studio Room:</strong> {bookingClass.room}</p>
                  <p className="text-amber-400">✨ <strong>Complimentary:</strong> Included with your 3-Day Free Pass or Membership</p>
                </div>

                <form onSubmit={handleBookSubmit} className="mt-5 space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Alex Sterling"
                      value={bookingForm.name}
                      onChange={(e) => setBookingForm({ ...bookingForm, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+1 (555) 000-0000"
                        value={bookingForm.phone}
                        onChange={(e) => setBookingForm({ ...bookingForm, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="alex@example.com"
                        value={bookingForm.email}
                        onChange={(e) => setBookingForm({ ...bookingForm, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/15 text-white text-sm focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-black font-bold text-sm shadow-lg shadow-amber-400/20 hover:scale-[1.02] transition-all cursor-pointer"
                  >
                    Confirm My Spot
                  </button>
                </form>
              </>
            ) : (
              <div className="text-center py-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h4 className="font-display text-3xl font-bold text-white uppercase">
                  Spot Reserved!
                </h4>
                <p className="mt-2 text-sm text-slate-300">
                  You are confirmed for <strong className="text-amber-400">{bookingClass.title}</strong> on{' '}
                  <strong>{bookingClass.day} at {bookingClass.time}</strong> with coach {bookingClass.instructor}.
                </p>

                <div className="mt-4 p-4 rounded-xl bg-white/5 border border-dashed border-amber-400/30 text-xs text-slate-300">
                  <div className="font-mono text-amber-400 font-bold text-base tracking-widest">
                    RESERVATION #{Math.floor(100000 + Math.random() * 900000)}
                  </div>
                  <p className="mt-1 text-slate-400">Please arrive 10 minutes early at the front desk with gym attire and a water bottle.</p>
                </div>

                <div className="mt-6 flex flex-col sm:flex-row gap-3">
                  <a
                    href={`https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
                      `Hi! I just reserved my spot for ${bookingClass.title} on ${bookingClass.day} at ${bookingClass.time} (Name: ${bookingForm.name}).`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-3 rounded-xl bg-[#25D366] text-black font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#20ba59]"
                  >
                    <Send className="w-4 h-4" />
                    Send Confirmation via WhatsApp
                  </a>

                  <button
                    onClick={handleCloseModal}
                    className="px-4 py-3 rounded-xl bg-white/10 text-white font-semibold text-xs hover:bg-white/15"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
