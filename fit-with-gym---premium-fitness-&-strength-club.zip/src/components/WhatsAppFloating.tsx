import React, { useState } from 'react';
import { MessageSquare, X, Send, Sparkles, Dumbbell } from 'lucide-react';
import { BUSINESS_INFO } from '../data/gymData';

export const WhatsAppFloating: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const quickPrompts = [
    'Claim 3-Day Free Pass',
    'Class Schedule & Times',
    'Personal Training Pricing',
    'Sauna & Cold Plunge Tour'
  ];

  const handleSend = (textToSend?: string) => {
    const finalMsg = textToSend || message || "Hi Fit With Gym! I'd like to ask a few questions.";
    const url = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(finalMsg)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Mini Chat Card Popup */}
      {isOpen && (
        <div className="mb-4 w-80 sm:w-96 bg-[#121927] border border-white/20 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#128C7E] to-[#25D366] p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-black/20 flex items-center justify-center font-bold text-white border border-white/20">
                <Dumbbell className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">Fit With Gym Concierge</h4>
                <div className="flex items-center gap-1.5 text-xs text-white/90">
                  <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                  <span>Typically replies in minutes</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-black/20 text-white/80 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 bg-[#0d131f] space-y-3 text-xs">
            <div className="bg-[#1b2538] text-slate-200 p-3 rounded-2xl rounded-tl-none border border-white/10 max-w-[85%]">
              <p>Hey there! 👋 Welcome to <strong className="text-amber-400">{BUSINESS_INFO.name}</strong>.</p>
              <p className="mt-1">How can our coaches help you today? Pick a quick option or write to us directly:</p>
            </div>

            {/* Quick Chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {quickPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(prompt)}
                  className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-amber-400/20 hover:border-amber-400/40 border border-white/10 text-slate-300 hover:text-amber-300 text-[11px] font-medium transition-colors text-left"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>

          {/* Input & Send */}
          <div className="p-3 bg-[#121927] border-t border-white/10 flex items-center gap-2">
            <input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              className="flex-1 px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-white text-xs focus:outline-none focus:border-[#25D366]"
            />
            <button
              onClick={() => handleSend()}
              className="p-2.5 rounded-xl bg-[#25D366] text-black hover:bg-[#20ba59] transition-colors"
              aria-label="Send WhatsApp message"
            >
              <Send className="w-4 h-4 fill-black" />
            </button>
          </div>
        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 px-4 py-3.5 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-black font-bold text-sm shadow-xl shadow-[#25D366]/30 hover:shadow-[#25D366]/50 hover:scale-105 active:scale-95 transition-all cursor-pointer"
        aria-label="Contact us on WhatsApp"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-black opacity-40"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-black"></span>
        </span>
        <MessageSquare className="w-5 h-5 fill-black" />
        <span className="hidden sm:inline font-bold">Chat on WhatsApp</span>
      </button>
    </div>
  );
};
