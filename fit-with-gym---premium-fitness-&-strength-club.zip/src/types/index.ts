export interface Program {
  id: string;
  title: string;
  category: 'strength' | 'hiit' | 'functional' | 'mobility' | 'personal';
  level: 'All Levels' | 'Intermediate' | 'Advanced' | 'Beginner Friendly';
  duration: string;
  intensity: 'High' | 'Extreme' | 'Moderate';
  calories: string;
  image: string;
  shortDesc: string;
  fullDesc: string;
  benefits: string[];
  equipment: string[];
  trainerName: string;
}

export interface ClassScheduleItem {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  time: string;
  title: string;
  category: 'strength' | 'hiit' | 'functional' | 'mobility' | 'boxing' | 'spin';
  instructor: string;
  room: string;
  capacity: number;
  bookedCount: number;
  intensity: 'Moderate' | 'High' | 'Extreme';
  duration: string;
}

export interface Trainer {
  id: string;
  name: string;
  role: string;
  experience: string;
  certifications: string[];
  specialties: string[];
  image: string;
  bio: string;
  quote: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  subtitle: string;
  monthlyPrice: number;
  annualPrice: number;
  popular?: boolean;
  features: string[];
  ctaText: string;
  badge?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'floor' | 'weights' | 'classes' | 'spa' | 'amenities';
  image: string;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  achievement: string;
  rating: number;
  review: string;
  image: string;
  memberSince: string;
}

export interface PassBooking {
  fullName: string;
  email: string;
  phone: string;
  preferredDate: string;
  goal: string;
  programInterest: string;
  passCode: string;
  generatedAt: string;
}
