import { Program, ClassScheduleItem, Trainer, PricingPlan, GalleryItem, Testimonial } from '../types';

export const BUSINESS_INFO = {
  name: 'Fit With Gym',
  tagline: 'Precision Training • Elite Conditioning • Modern Recovery',
  phone: '+1 (555) 348-9496',
  whatsappNumber: '15553489496',
  email: 'hello@fitwithgym.com',
  address: '742 Ironworks Boulevard, West District, Suite 100',
  city: 'Metropolis, NY 10012',
  hours: {
    weekdays: '5:00 AM – 11:00 PM',
    weekends: '6:00 AM – 9:00 PM',
    twentyFourSeven: '24/7 Keycard Access for Pro & VIP Members'
  },
  stats: {
    sqft: '16,500',
    coaches: '14',
    classesWeekly: '55+',
    satisfaction: '99.4%'
  }
};

export const PROGRAMS: Program[] = [
  {
    id: 'prog-strength',
    title: 'Hypertrophy & Strength Lab',
    category: 'strength',
    level: 'All Levels',
    duration: '60 min',
    intensity: 'High',
    calories: '450 - 650 kcal',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80',
    shortDesc: 'Systematic barbell & dumbbell progression engineered to build dense lean muscle, bone density, and raw strength.',
    fullDesc: 'Structured around compound lifts (squat, bench, deadlift, overhead press) integrated with targeted accessory hypertrophy protocols. Our coaches ensure flawless biomechanics and progressive overload tracking.',
    benefits: ['Progressive overload tracking', 'Compound lifting technique coaching', 'Periodized strength blocks', 'Injury prevention and tendon health'],
    equipment: ['Eleiko Olympic barbells & calibrated plates', 'Custom power racks with safety straps', 'Arsenal Strength incline & hack squats'],
    trainerName: 'Marcus Vance'
  },
  {
    id: 'prog-hiit',
    title: 'Metabolic Ignite HIIT',
    category: 'hiit',
    level: 'All Levels',
    duration: '45 min',
    intensity: 'Extreme',
    calories: '600 - 850 kcal',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1200&q=80',
    shortDesc: 'High-octane interval conditioning utilizing ski-ergs, assault bikes, battle ropes, and kettlebell intervals.',
    fullDesc: 'Accelerate your cardiovascular capacity and maximize the post-exercise oxygen consumption (EPOC) burn for up to 36 hours. Designed with heart-rate telemetry on our visual video wall.',
    benefits: ['Maximum cardiovascular endurance', 'Prolonged 24-48h calorie burn', 'Live heart-rate target zones', 'Athletic agility and anaerobic speed'],
    equipment: ['Concept2 Rowers & SkiErgs', 'Echo assault bikes', 'Torque tank sleds & plyo boxes'],
    trainerName: 'Elena Rostova'
  },
  {
    id: 'prog-functional',
    title: 'Functional Athletic Performance',
    category: 'functional',
    level: 'Intermediate',
    duration: '50 min',
    intensity: 'High',
    calories: '500 - 700 kcal',
    image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?auto=format&fit=crop&w=1200&q=80',
    shortDesc: 'Full-body functional movement patterns combining kettlebells, sled sprints, sandbags, and bodyweight gymnastics.',
    fullDesc: 'Train like an athlete for real-world resilience, rotational core power, and joint stability. Perfect for those who want both functional power and an aesthetic, balanced physique.',
    benefits: ['Multi-planar movement & core stability', 'Posterior chain horsepower', 'Grip strength & balance', 'High work capacity across all domains'],
    equipment: ['Rogue kettlebells & slam balls', 'Turf sled lane & battle ropes', 'Gymnastic rings & pull-up rigs'],
    trainerName: 'David Chen'
  },
  {
    id: 'prog-mobility',
    title: 'Vinyasa Flow & Thermal Mobility',
    category: 'mobility',
    level: 'Beginner Friendly',
    duration: '55 min',
    intensity: 'Moderate',
    calories: '250 - 350 kcal',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1200&q=80',
    shortDesc: 'Restorative mobility, myofascial release, deep hip opening, and breathwork to decompress tense joints.',
    fullDesc: 'The ultimate counter-balance to heavy lifting and daily desk posture. Increase range of motion, alleviate lower back tension, and calm your central nervous system before hot sauna recovery.',
    benefits: ['Deep joint decompression & flexibility', 'Lower back & shoulder pain relief', 'Parasympathetic nervous system recovery', 'Enhanced athletic movement efficiency'],
    equipment: ['Manduka Pro yoga mats & blocks', 'Foam rollers & lacrosse mobility spheres', 'Resistance stretching bands'],
    trainerName: 'Maya Patel'
  },
  {
    id: 'prog-personal',
    title: '1-on-1 Bespoke Personal Coaching',
    category: 'personal',
    level: 'All Levels',
    duration: '60 min',
    intensity: 'High',
    calories: 'Custom tailored',
    image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&w=1200&q=80',
    shortDesc: 'Comprehensive personalized training, InBody 570 body scan analysis, and daily nutritional macro roadmap.',
    fullDesc: 'Work directly alongside our master trainers with 100% individual attention. We assess your joint mobility, past injuries, body composition, and craft a scientific periodized program for rapid, sustainable results.',
    benefits: ['Custom-tailored programming & nutrition', 'Bi-weekly InBody 570 body scans', 'Direct coach WhatsApp check-ins', 'Guaranteed technical mastery'],
    equipment: ['Dedicated private trainer bay', 'Velocity-based training encoders', 'Complete gym access'],
    trainerName: 'Marcus Vance & Elena Rostova'
  }
];

export const SCHEDULE_ITEMS: ClassScheduleItem[] = [
  // Monday
  { id: 'sch-m1', day: 'Monday', time: '06:00 AM', title: 'Dawn Patrol Strength', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 14, intensity: 'High', duration: '55 min' },
  { id: 'sch-m2', day: 'Monday', time: '07:30 AM', title: 'Metabolic Ignite HIIT', category: 'hiit', instructor: 'Elena Rostova', room: 'Cardio Arena', capacity: 20, bookedCount: 18, intensity: 'Extreme', duration: '45 min' },
  { id: 'sch-m3', day: 'Monday', time: '12:00 PM', title: 'Express Core & Kettlebell', category: 'functional', instructor: 'David Chen', room: 'Turf Zone', capacity: 18, bookedCount: 12, intensity: 'High', duration: '40 min' },
  { id: 'sch-m4', day: 'Monday', time: '05:30 PM', title: 'Heavy Barbell Hypertrophy', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 16, intensity: 'High', duration: '60 min' },
  { id: 'sch-m5', day: 'Monday', time: '06:45 PM', title: 'Cardio Kick & Boxing', category: 'boxing', instructor: 'Elena Rostova', room: 'Combat Loft', capacity: 15, bookedCount: 11, intensity: 'Extreme', duration: '50 min' },
  { id: 'sch-m6', day: 'Monday', time: '07:45 PM', title: 'Decompress Yoga & Sound', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 22, bookedCount: 15, intensity: 'Moderate', duration: '55 min' },

  // Tuesday
  { id: 'sch-t1', day: 'Tuesday', time: '06:30 AM', title: 'Functional Sleds & Turf', category: 'functional', instructor: 'David Chen', room: 'Turf Zone', capacity: 18, bookedCount: 15, intensity: 'High', duration: '50 min' },
  { id: 'sch-t2', day: 'Tuesday', time: '08:00 AM', title: 'High-RPM Rhythm Spin', category: 'spin', instructor: 'Elena Rostova', room: 'Cycle Studio', capacity: 24, bookedCount: 20, intensity: 'Extreme', duration: '45 min' },
  { id: 'sch-t3', day: 'Tuesday', time: '12:30 PM', title: 'Shoulder & Hip Mobility', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 20, bookedCount: 10, intensity: 'Moderate', duration: '45 min' },
  { id: 'sch-t4', day: 'Tuesday', time: '06:00 PM', title: 'Olympic Clean & Jerk Workshop', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 14, bookedCount: 12, intensity: 'High', duration: '60 min' },
  { id: 'sch-t5', day: 'Tuesday', time: '07:15 PM', title: 'HIIT Tabata Inferno', category: 'hiit', instructor: 'David Chen', room: 'Cardio Arena', capacity: 20, bookedCount: 17, intensity: 'Extreme', duration: '45 min' },

  // Wednesday
  { id: 'sch-w1', day: 'Wednesday', time: '06:00 AM', title: 'Deadlift & Posterior Chain', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 15, intensity: 'High', duration: '60 min' },
  { id: 'sch-w2', day: 'Wednesday', time: '07:15 AM', title: 'Cardio Conditioning', category: 'hiit', instructor: 'Elena Rostova', room: 'Cardio Arena', capacity: 20, bookedCount: 14, intensity: 'High', duration: '45 min' },
  { id: 'sch-w3', day: 'Wednesday', time: '05:30 PM', title: 'Functional Athletic Grit', category: 'functional', instructor: 'David Chen', room: 'Turf Zone', capacity: 18, bookedCount: 17, intensity: 'Extreme', duration: '50 min' },
  { id: 'sch-w4', day: 'Wednesday', time: '06:45 PM', title: 'Power Vinyasa Flow', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 22, bookedCount: 19, intensity: 'Moderate', duration: '55 min' },

  // Thursday
  { id: 'sch-th1', day: 'Thursday', time: '06:30 AM', title: 'HIIT Ski-Erg & Rower', category: 'hiit', instructor: 'Elena Rostova', room: 'Cardio Arena', capacity: 20, bookedCount: 16, intensity: 'Extreme', duration: '45 min' },
  { id: 'sch-th2', day: 'Thursday', time: '08:00 AM', title: 'Bench & Upper Body Pump', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 14, intensity: 'High', duration: '55 min' },
  { id: 'sch-th3', day: 'Thursday', time: '06:00 PM', title: 'Boxing Rounds & Heavy Bags', category: 'boxing', instructor: 'David Chen', room: 'Combat Loft', capacity: 16, bookedCount: 15, intensity: 'Extreme', duration: '50 min' },
  { id: 'sch-th4', day: 'Thursday', time: '07:15 PM', title: 'Deep Fascial Release & Breath', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 20, bookedCount: 12, intensity: 'Moderate', duration: '50 min' },

  // Friday
  { id: 'sch-f1', day: 'Friday', time: '06:00 AM', title: 'Friday Fast Track HIIT', category: 'hiit', instructor: 'Elena Rostova', room: 'Cardio Arena', capacity: 20, bookedCount: 18, intensity: 'Extreme', duration: '45 min' },
  { id: 'sch-f2', day: 'Friday', time: '07:30 AM', title: 'Full Body Armour Strength', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 13, intensity: 'High', duration: '60 min' },
  { id: 'sch-f3', day: 'Friday', time: '05:30 PM', title: 'Weekend Warmup Athletic Team', category: 'functional', instructor: 'David Chen', room: 'Turf Zone', capacity: 22, bookedCount: 20, intensity: 'High', duration: '55 min' },
  { id: 'sch-f4', day: 'Friday', time: '06:45 PM', title: 'Candlelight Yin Yoga', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 22, bookedCount: 18, intensity: 'Moderate', duration: '60 min' },

  // Saturday
  { id: 'sch-sa1', day: 'Saturday', time: '08:00 AM', title: 'Weekend Warrior Super-Circuit', category: 'functional', instructor: 'David Chen', room: 'Turf Zone', capacity: 25, bookedCount: 24, intensity: 'Extreme', duration: '60 min' },
  { id: 'sch-sa2', day: 'Saturday', time: '09:30 AM', title: 'Power Lifting Club', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 15, intensity: 'High', duration: '75 min' },
  { id: 'sch-sa3', day: 'Saturday', time: '11:00 AM', title: 'Sweat & Spin Surge', category: 'spin', instructor: 'Elena Rostova', room: 'Cycle Studio', capacity: 24, bookedCount: 22, intensity: 'High', duration: '50 min' },
  { id: 'sch-sa4', day: 'Saturday', time: '01:00 PM', title: 'Restorative Spine & Hips', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 20, bookedCount: 14, intensity: 'Moderate', duration: '55 min' },

  // Sunday
  { id: 'sch-su1', day: 'Sunday', time: '09:00 AM', title: 'Sunday Strength Foundations', category: 'strength', instructor: 'Marcus Vance', room: 'Power Bay 1', capacity: 16, bookedCount: 11, intensity: 'Moderate', duration: '60 min' },
  { id: 'sch-su2', day: 'Sunday', time: '10:30 AM', title: 'Full Spectrum Mobility & Breath', category: 'mobility', instructor: 'Maya Patel', room: 'Zen Studio', capacity: 24, bookedCount: 21, intensity: 'Moderate', duration: '60 min' },
  { id: 'sch-su3', day: 'Sunday', time: '12:00 PM', title: 'Recovery Sauna & Cold Immersion', category: 'functional', instructor: 'David Chen', room: 'Recovery Suite', capacity: 15, bookedCount: 13, intensity: 'Moderate', duration: '45 min' }
];

export const TRAINERS: Trainer[] = [
  {
    id: 'tr-marcus',
    name: 'Marcus Vance',
    role: 'Head of Strength & Conditioning',
    experience: '11+ Years Coaching',
    certifications: ['CSCS (NSCA)', 'USA Weightlifting L2', 'EXOS Performance Specialist'],
    specialties: ['Olympic Weightlifting', 'Barbell Mechanics', 'Hypertrophy Periodization'],
    image: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=800&q=80',
    bio: 'Former collegiate decathlete passionate about biomechanical efficiency. Marcus has coached over 300 competitive athletes and everyday lifters to record PRs without joint pain.',
    quote: 'Discipline is doing what needs to be done, even when motivation disappears.'
  },
  {
    id: 'tr-elena',
    name: 'Elena Rostova',
    role: 'Lead Functional & HIIT Coach',
    experience: '8+ Years Coaching',
    certifications: ['NASM-CPT', 'CrossFit L3', 'Precision Nutrition L1'],
    specialties: ['Metabolic Conditioning', 'Kettlebell Sport', 'Body Recomposition'],
    image: 'https://images.unsplash.com/photo-1548690312-e3b507d8c110?auto=format&fit=crop&w=800&q=80',
    bio: 'High-energy coach specialized in cardiovascular capacity and anaerobic power. Elena designs programming that burns fat while keeping workouts empowering and fun.',
    quote: 'You do not have to be extreme, just relentlessly consistent.'
  },
  {
    id: 'tr-david',
    name: 'David Chen',
    role: 'Athletic Performance & Injury Prevention',
    experience: '9+ Years Coaching',
    certifications: ['ACSM Certified Exercise Physiologist', 'FMS L2', 'TRX Master Instructor'],
    specialties: ['Rotational Power', 'Sled & Sprint Mechanics', 'Post-Rehab Bridging'],
    image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=800&q=80',
    bio: 'David combines sports science with functional training to help busy professionals build bulletproof bodies that perform as well as they look in the mirror.',
    quote: 'Train the movement, not just the muscle.'
  },
  {
    id: 'tr-maya',
    name: 'Maya Patel',
    role: 'Mobility, Yoga & Recovery Specialist',
    experience: '7+ Years Coaching',
    certifications: ['E-RYT 500 Yoga Alliance', 'FRC Mobility Specialist (Functional Range)', 'Wim Hof Breathwork'],
    specialties: ['Vinyasa & Yin Flow', 'Hip & Spine Decompression', 'Breathwork & Nervous System'],
    image: 'https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&w=800&q=80',
    bio: 'Believes true strength requires equal parts force production and effortless recovery. She leads our mobility classes and sauna thermal recovery sessions.',
    quote: 'Flexibility is physical; mobility is strength through full range.'
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'plan-day',
    name: 'Day Pass',
    subtitle: 'Ideal for travelers & drop-ins',
    monthlyPrice: 20,
    annualPrice: 20,
    features: [
      'Single-day all-area gym access',
      'Access to open weight floor & turf',
      'Locker room & luxury shower access',
      'Free high-speed WiFi',
      'Complementary towel service'
    ],
    ctaText: 'Buy Day Pass',
    badge: 'Single Visit'
  },
  {
    id: 'plan-core',
    name: 'Core Strength',
    subtitle: 'Essential training for focused lifters',
    monthlyPrice: 59,
    annualPrice: 49,
    features: [
      'Full access during standard hours (5am-11pm)',
      'Free weights, Olympic racks & cardio floor',
      'Locker room & private shower suites',
      'Free mobile check-in app',
      '1x Initial InBody 570 body scan',
      'Discounted shake bar access'
    ],
    ctaText: 'Choose Core',
  },
  {
    id: 'plan-pro',
    name: 'Pro All-Access',
    subtitle: 'Our most popular membership for results',
    monthlyPrice: 99,
    annualPrice: 79,
    popular: true,
    badge: 'Most Popular',
    features: [
      '24/7 Keycard & biometric RFID access',
      'Unlimited weekly group classes (HIIT, Spin, Boxing)',
      'Finnish sauna & cold plunge thermal suite',
      'Monthly InBody 570 body composition scans',
      '2 Guest passes per month for friends',
      '1x 1-on-1 Personal coaching session included',
      '15% off fuel bar & supplements'
    ],
    ctaText: 'Join Pro All-Access',
  },
  {
    id: 'plan-vip',
    name: 'VIP Elite Performance',
    subtitle: 'Uncompromising luxury & dedicated coaching',
    monthlyPrice: 169,
    annualPrice: 139,
    features: [
      '24/7 Unlimited priority club access',
      '2x 1-on-1 Personal training sessions every month',
      'Full unlimited group & masterclasses',
      'Daily sauna, cold plunge & normatec compression',
      'Unlimited guest privileges (bring anyone)',
      'Personal locker with laundry kit service',
      'Custom nutritional meal plans & macro guide',
      'Dedicated coach direct WhatsApp access'
    ],
    ctaText: 'Claim VIP Elite',
    badge: 'All Inclusive'
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Olympic Lifting & Racks',
    category: 'weights',
    image: 'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&w=1200&q=80',
    description: 'Custom power racks with Eleiko Olympic barbells and bumper plates.'
  },
  {
    id: 'gal-2',
    title: 'High-Octane Turf & Functional Zone',
    category: 'floor',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1200&q=80',
    description: '40-yard athletic turf with sleds, battle ropes, and plyometric boxes.'
  },
  {
    id: 'gal-3',
    title: 'Dynamic Group Studio',
    category: 'classes',
    image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1200&q=80',
    description: 'State-of-the-art sound system and studio lighting for group energy.'
  },
  {
    id: 'gal-4',
    title: 'Finnish Cedar Sauna & Thermal Recovery',
    category: 'spa',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
    description: 'Traditional wood sauna and 45°F cold plunge pools for cellular recovery.'
  },
  {
    id: 'gal-5',
    title: 'Dumbbell Arsenal Up to 150 lbs',
    category: 'weights',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1200&q=80',
    description: 'Complete urethane dumbbell line with multiple adjustable benches.'
  },
  {
    id: 'gal-6',
    title: 'Fuel Shake & Espresso Bar',
    category: 'amenities',
    image: 'https://images.unsplash.com/photo-1577221084712-45b0445d2b00?auto=format&fit=crop&w=1200&q=80',
    description: 'Fresh organic protein smoothies, electrolyte drinks, and artisan cold brew.'
  },
  {
    id: 'gal-7',
    title: 'Cardio Loft with Panoramic Views',
    category: 'floor',
    image: 'https://images.unsplash.com/photo-1576678927484-cc907957088c?auto=format&fit=crop&w=1200&q=80',
    description: 'Woodway curved treadmills, Concept2 rowers, and Stairmasters.'
  },
  {
    id: 'gal-8',
    title: 'Luxury Locker & Rain Shower Suites',
    category: 'amenities',
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=1200&q=80',
    description: 'Spacious vanity areas, fresh towels, grooming products, and steam.'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Julian Vance',
    role: 'Software Architect',
    achievement: 'Lost 32 lbs & Deadlifts 405 lbs',
    rating: 5,
    review: 'Fit With Gym is on another level compared to standard commercial gyms. The equipment is top-tier, never overcrowded, and the coaching team genuinely cares about your progress. Marcus rebuilt my lifting form completely.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    memberSince: 'Member for 2 years'
  },
  {
    id: 'test-2',
    name: 'Sarah Lindqvist',
    role: 'Corporate Attorney',
    achievement: 'Completed First Half Marathon',
    rating: 5,
    review: 'The morning Metabolic Ignite classes give me an unbeatable mental boost for the workday. The sauna and cold plunge after a brutal session are pure bliss. Hands down the best gym investment I’ve ever made.',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    memberSince: 'Member for 14 months'
  },
  {
    id: 'test-3',
    name: 'Carlos Mendez',
    role: 'High School Athletic Coach',
    achievement: 'Added 40 lbs to Squat in 12 Weeks',
    rating: 5,
    review: 'As a coach myself, I am very picky about gym culture and bar quality. Fit With Gym gets everything right: calibrated plates, clean turf, respectful members, and world-class equipment maintenance.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    memberSince: 'Member for 3 years'
  }
];

export const FAQS = [
  {
    q: 'Can beginners join Fit With Gym?',
    a: 'Absolutely! More than 40% of our members started here with zero lifting experience. Every new membership includes a free 1-on-1 orientation and movement screening with a certified trainer to guide you step-by-step through our equipment and safe form.'
  },
  {
    q: 'How does the 3-Day Free All-Access Pass work?',
    a: 'When you claim your pass online, you receive an instant digital VIP Pass with your name and access code. Show this at our front desk anytime during staffed hours. You get full access to the gym floor, all group classes, and the recovery sauna for 3 consecutive days with no obligations or hidden fees.'
  },
  {
    q: 'What are the peak and quiet hours?',
    a: 'Peak hours are typically weekdays from 6:30 AM – 8:30 AM and 5:30 PM – 7:30 PM. For a quieter workout, late mornings (9:30 AM – 11:30 AM) and early afternoons (1:30 PM – 4:30 PM) offer spacious, uninterrupted access to all racks and machines.'
  },
  {
    q: 'Are locker rooms, showers, and towel service included?',
    a: 'Yes! All memberships include full access to our luxury locker suites featuring private rain showers, keyless digital lockers, complimentary bath towels, and organic grooming products.'
  },
  {
    q: 'Can I freeze or cancel my membership?',
    a: 'Yes. We believe in earning your loyalty every month. Memberships have no lock-in contracts after the initial month. You can freeze your account for up to 60 days per year or cancel with 14 days simple written notice.'
  },
  {
    q: 'How do I book classes?',
    a: 'You can book classes directly on this website under the Schedule tab or via our WhatsApp concierge. Classes open for reservation 7 days in advance.'
  }
];
